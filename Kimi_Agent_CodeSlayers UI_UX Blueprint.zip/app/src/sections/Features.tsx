import { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Code, Swords, Brain, Repeat, ArrowRight, Check } from 'lucide-react';
import { featuresConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

const ICON_MAP = {
  code: Code,
  sword: Swords,
  brain: Brain,
  repeat: Repeat,
};

const Features = () => {
  // Null check: if config is empty, do not render
  if (featuresConfig.features.length === 0 && !featuresConfig.sectionTitle) {
    return null;
  }

  const sectionRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const featuresRef = useRef<HTMLDivElement>(null);
  const tracksRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (!sectionRef.current) return;

    const st = ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top 80%',
      onEnter: () => setIsVisible(true),
    });

    return () => {
      st.kill();
    };
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    const ctx = gsap.context(() => {
      // Headline animation
      gsap.fromTo(
        headlineRef.current,
        { y: 40, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out' }
      );

      // Features animation
      gsap.fromTo(
        featuresRef.current?.querySelectorAll('.feature-item') || [],
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power3.out', delay: 0.2 }
      );

      // Tracks animation
      gsap.fromTo(
        tracksRef.current?.querySelectorAll('.track-item') || [],
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6, stagger: 0.15, ease: 'power3.out', delay: 0.4 }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, [isVisible]);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="courses"
      ref={sectionRef}
      className="relative w-full bg-[#0B0B0D] py-24 overflow-hidden"
    >
      {/* Content container */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 md:px-12">
        {/* Section header */}
        <div ref={headlineRef} className="mb-16" style={{ opacity: 0 }}>
          <p className="font-mono-custom text-xs text-[#FF4D00]/60 uppercase tracking-wider mb-2">
            {featuresConfig.sectionLabel}
          </p>
          <h2 className="font-display text-5xl md:text-6xl text-white mb-6">
            {featuresConfig.sectionTitle}
          </h2>
          <p className="font-mono-custom text-lg text-[#A1A1AA] max-w-2xl">
            {featuresConfig.body}
          </p>
        </div>

        {/* Features grid */}
        <div ref={featuresRef} className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-20">
          {featuresConfig.features.map((feature) => {
            const IconComponent = ICON_MAP[feature.icon as keyof typeof ICON_MAP];
            return (
              <div
                key={feature.id}
                className="feature-item card-dark p-8 group hover:-translate-y-1.5 transition-transform duration-300"
                style={{ opacity: 0 }}
              >
                <div className="flex items-start gap-6">
                  <div className="w-14 h-14 rounded-xl bg-[#FF4D00]/10 flex items-center justify-center flex-shrink-0 group-hover:bg-[#FF4D00]/20 transition-colors">
                    <IconComponent className="w-7 h-7 text-[#FF4D00]" />
                  </div>
                  <div>
                    <h3 className="font-display text-xl text-white mb-2 group-hover:text-[#FF4D00] transition-colors">
                      {feature.title}
                    </h3>
                    <p className="font-mono-custom text-sm text-[#A1A1AA] leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Learning Tracks */}
        <div ref={tracksRef} className="mb-16">
          <h3 className="font-display text-2xl text-white mb-8">Learning Tracks</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {featuresConfig.tracks.map((track) => (
              <div
                key={track.id}
                className="track-item card-dark p-8"
                style={{ opacity: 0, borderLeft: `3px solid ${track.color}` }}
              >
                <h4 className="font-display text-xl text-white mb-4">{track.name}</h4>
                <div className="space-y-3">
                  {track.modules.map((module, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <div
                        className="w-6 h-6 rounded-full flex items-center justify-center"
                        style={{ background: `${track.color}20` }}
                      >
                        <Check className="w-3 h-3" style={{ color: track.color }} />
                      </div>
                      <span className="font-mono-custom text-sm text-[#A1A1AA]">{module}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <button
            onClick={() => scrollToSection(featuresConfig.ctaTarget)}
            className="btn-primary inline-flex items-center gap-2"
          >
            {featuresConfig.ctaText}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF4D00]/20 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF4D00]/20 to-transparent" />
    </section>
  );
};

export default Features;
