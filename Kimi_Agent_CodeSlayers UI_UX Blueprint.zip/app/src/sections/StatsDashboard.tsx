import { useRef, useEffect, useState, Suspense } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { useTexture } from '@react-three/drei';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import * as THREE from 'three';
import { Flame, Shield, Zap, Star } from 'lucide-react';
import { statsConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

const ICON_MAP = {
  flame: Flame,
  shield: Shield,
  zap: Zap,
  star: Star,
};

interface CubeProps {
  rotationProgress: number;
}

const Cube = ({ rotationProgress }: CubeProps) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const { viewport } = useThree();

  const textures = useTexture(statsConfig.cubeTextures);

  // Responsive cube size
  const cubeSize = Math.min(viewport.width * 0.35, 2.5);

  useFrame(() => {
    if (meshRef.current) {
      // Map rotation progress (0-1) to rotation angles
      const targetRotationY = rotationProgress * Math.PI * 1.5;
      const targetRotationX = Math.sin(rotationProgress * Math.PI) * 0.2;

      // Smooth interpolation
      meshRef.current.rotation.y = THREE.MathUtils.lerp(
        meshRef.current.rotation.y,
        targetRotationY,
        0.08
      );
      meshRef.current.rotation.x = THREE.MathUtils.lerp(
        meshRef.current.rotation.x,
        targetRotationX,
        0.08
      );
    }
  });

  return (
    <mesh ref={meshRef} castShadow>
      <boxGeometry args={[cubeSize, cubeSize, cubeSize]} />
      {textures.map((texture, index) => (
        <meshStandardMaterial
          key={index}
          attach={`material-${index}`}
          map={texture}
          roughness={0.3}
          metalness={0.2}
          emissive={index % 2 === 0 ? '#FF4D00' : '#7C3AED'}
          emissiveIntensity={0.05}
        />
      ))}
    </mesh>
  );
};

const StatsDashboard = () => {
  // Null check: if config is empty, do not render
  if (statsConfig.stats.length === 0 || statsConfig.cubeTextures.length === 0) {
    return null;
  }

  const sectionRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const [rotationProgress, setRotationProgress] = useState(0);
  const scrollTriggerRef = useRef<ScrollTrigger | null>(null);

  useEffect(() => {
    if (!sectionRef.current) return;

    const ctx = gsap.context(() => {
      // Main scroll animation
      const st = ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top top',
        end: '+=140%',
        pin: true,
        scrub: 0.7,
        onUpdate: (self) => {
          const progress = self.progress;
          setRotationProgress(progress);

          // ENTRANCE (0% - 30%)
          if (progress <= 0.3) {
            const entranceProgress = progress / 0.3;
            
            // Panel entrance
            if (panelRef.current) {
              gsap.set(panelRef.current, {
                x: -50 * (1 - entranceProgress) + 'vw',
                rotateY: 18 * (1 - entranceProgress),
                opacity: entranceProgress,
              });
            }
            
            // Canvas entrance
            if (canvasContainerRef.current) {
              gsap.set(canvasContainerRef.current, {
                x: 50 * (1 - entranceProgress) + 'vw',
                opacity: entranceProgress,
              });
            }
          }
          // SETTLE (30% - 70%)
          else if (progress <= 0.7) {
            if (panelRef.current) {
              gsap.set(panelRef.current, {
                x: 0,
                rotateY: 0,
                opacity: 1,
              });
            }
            if (canvasContainerRef.current) {
              gsap.set(canvasContainerRef.current, {
                x: 0,
                opacity: 1,
              });
            }
          }
          // EXIT (70% - 100%)
          else {
            const exitProgress = (progress - 0.7) / 0.3;
            
            if (panelRef.current) {
              gsap.set(panelRef.current, {
                x: -40 * exitProgress + 'vw',
                opacity: 1 - exitProgress * 0.7,
              });
            }
            if (canvasContainerRef.current) {
              gsap.set(canvasContainerRef.current, {
                x: 40 * exitProgress + 'vw',
                opacity: 1 - exitProgress * 0.75,
              });
            }
          }
        },
      });

      scrollTriggerRef.current = st;

      return () => {
        st.kill();
      };
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="stats"
      ref={sectionRef}
      className="relative w-full h-screen bg-[#0B0B0D] overflow-hidden z-20"
    >
      {/* Left panel - Stats Dashboard */}
      <div
        ref={panelRef}
        className="absolute left-[6vw] top-[18vh] w-[34vw] h-[64vh] card-dark p-8 flex flex-col justify-between"
        style={{ opacity: 0 }}
      >
        {/* Header */}
        <div>
          <p className="font-mono-custom text-xs text-[#FF4D00]/60 uppercase tracking-wider mb-2">
            {statsConfig.title}
          </p>
          <h3 className="font-display text-2xl text-white">{statsConfig.subtitle}</h3>
        </div>

        {/* Stats List */}
        <div className="space-y-6">
          {statsConfig.stats.map((stat, index) => {
            const IconComponent = ICON_MAP[stat.icon as keyof typeof ICON_MAP];
            return (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center">
                    <IconComponent className="w-5 h-5 text-[#FF4D00]" />
                  </div>
                  <span className="font-mono-custom text-sm text-[#A1A1AA]">{stat.label}</span>
                </div>
                <span className="font-display text-lg text-white">{stat.value}</span>
              </div>
            );
          })}
        </div>

        {/* XP Progress Bar */}
        <div>
          <div className="flex justify-between mb-2">
            <span className="font-mono-custom text-xs text-[#A1A1AA]">XP Progress</span>
            <span className="font-mono-custom text-xs text-[#FF4D00]">84%</span>
          </div>
          <div className="h-2 progress-bar-track rounded-full overflow-hidden">
            <div className="h-full progress-bar-fill rounded-full" style={{ width: '84%' }} />
          </div>
        </div>

        {/* Note */}
        <p className="font-mono-custom text-xs text-[#A1A1AA]/60 leading-relaxed">
          {statsConfig.note}
        </p>

        {/* CTA */}
        <button className="btn-primary w-full">
          {statsConfig.ctaText}
        </button>
      </div>

      {/* Right side - 3D Cube */}
      <div
        ref={canvasContainerRef}
        className="absolute right-[6vw] top-[10vh] w-[48vw] h-[80vh]"
        style={{ opacity: 0 }}
      >
        <Canvas
          camera={{ position: [0, 0, 5], fov: 50 }}
          gl={{ antialias: true, alpha: true }}
        >
          <Suspense fallback={null}>
            <ambientLight intensity={0.5} />
            <spotLight
              position={[10, 10, 10]}
              angle={0.2}
              penumbra={1}
              intensity={1.2}
              castShadow
              color="#FF4D00"
            />
            <spotLight
              position={[-10, -10, -10]}
              angle={0.2}
              penumbra={1}
              intensity={0.8}
              color="#7C3AED"
            />
            <pointLight position={[0, 0, 5]} intensity={0.6} color="#FF4D00" />
            <Cube rotationProgress={rotationProgress} />
          </Suspense>
        </Canvas>
      </div>

      {/* Scroll hint */}
      <div className="absolute bottom-8 right-8 z-20">
        <p className="font-mono-custom text-xs text-white/40">{statsConfig.scrollHint}</p>
      </div>

      {/* Decorative corner lines */}
      <div className="absolute top-12 left-12 w-20 h-px bg-gradient-to-r from-[#FF4D00]/50 to-transparent" />
      <div className="absolute top-12 left-12 w-px h-20 bg-gradient-to-b from-[#FF4D00]/50 to-transparent" />
    </section>
  );
};

export default StatsDashboard;
