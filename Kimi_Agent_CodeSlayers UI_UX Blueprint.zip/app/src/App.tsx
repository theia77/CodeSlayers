import { useEffect } from 'react';
import './index.css';
import useLenis from './hooks/useLenis';
import { siteConfig } from './config';
import Hero from './sections/Hero';
import StatsDashboard from './sections/StatsDashboard';
import ProblemGallery from './sections/ProblemGallery';
import Features from './sections/Features';
import Contests from './sections/Contests';
import CTASection from './sections/CTASection';
import Footer from './sections/Footer';

function App() {
  // Initialize Lenis smooth scrolling
  useLenis();

  useEffect(() => {
    // Set page title from config
    if (siteConfig.title) {
      document.title = siteConfig.title;
    }

    // Add viewport meta for better mobile experience
    const metaViewport = document.querySelector('meta[name="viewport"]');
    if (metaViewport) {
      metaViewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
    }
  }, []);

  return (
    <main className="relative w-full min-h-screen bg-[#0B0B0D] overflow-x-hidden">
      {/* Grain overlay */}
      <div className="grain-overlay" />
      
      {/* Vignette overlay */}
      <div className="vignette-overlay" />

      {/* Hero Section - Immersive landing */}
      <Hero />

      {/* Stats Dashboard Section - 3D Cube + Stats Panel */}
      <StatsDashboard />

      {/* Problem Gallery Section - Horizontal scrolling cards */}
      <ProblemGallery />

      {/* Features Section - Learning tracks and features */}
      <Features />

      {/* Contests Section - Daily challenges and contests */}
      <Contests />

      {/* CTA Section - Full-screen call to action */}
      <CTASection />

      {/* Footer Section */}
      <Footer />
    </main>
  );
}

export default App;
