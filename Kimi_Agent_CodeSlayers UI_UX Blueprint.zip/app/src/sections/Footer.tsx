import { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Code, Mail, ExternalLink, ArrowRight } from 'lucide-react';
import { footerConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

const Footer = () => {
  // Null check: if config is empty, do not render
  if (!footerConfig.brandName && footerConfig.quickLinks.length === 0) {
    return null;
  }

  const sectionRef = useRef<HTMLDivElement>(null);
  const newsletterRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  useEffect(() => {
    if (!sectionRef.current) return;

    const ctx = gsap.context(() => {
      // Newsletter animation
      gsap.fromTo(
        newsletterRef.current,
        { y: 24, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
          },
        }
      );

      // Footer columns animation
      gsap.fromTo(
        sectionRef.current?.querySelectorAll('.footer-column') || [],
        { y: 20, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.08,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setTimeout(() => {
        alert(footerConfig.subscribeAlertMessage);
      }, 300);
    }
  };

  return (
    <footer
      id="contact"
      ref={sectionRef}
      className="relative w-full bg-[#0B0B0D] py-20 overflow-hidden"
    >
      {/* Top divider */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF4D00]/20 to-transparent" />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Newsletter section */}
        <div
          ref={newsletterRef}
          className="text-center mb-20"
          style={{ opacity: 0 }}
        >
          <h3 className="font-display text-3xl md:text-4xl text-white mb-4">
            {footerConfig.newsletterTitle}
          </h3>
          <p className="font-mono-custom text-sm text-[#A1A1AA] mb-8">
            {footerConfig.newsletterDescription}
          </p>
          
          {!subscribed ? (
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={footerConfig.newsletterPlaceholder}
                className="flex-grow px-5 py-3 bg-white/5 border border-white/10 rounded-full text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-[#FF4D00]/50 transition-colors"
              />
              <button
                type="submit"
                className="btn-primary flex items-center justify-center gap-2"
              >
                {footerConfig.newsletterButtonText}
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <div className="flex items-center justify-center gap-2 text-[#FF4D00]">
              <Code className="w-5 h-5" />
              <span className="font-mono-custom text-sm">Subscribed!</span>
            </div>
          )}
        </div>

        {/* Footer grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-16">
          {/* Brand */}
          <div className="footer-column" style={{ opacity: 0 }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-[#FF4D00]/20 flex items-center justify-center">
                <Code className="w-5 h-5 text-[#FF4D00]" />
              </div>
              <span className="font-display text-2xl text-white">{footerConfig.brandName}</span>
            </div>
            <p className="text-sm text-[#A1A1AA] leading-relaxed">
              {footerConfig.brandDescription}
            </p>
          </div>

          {/* Quick Links */}
          <div className="footer-column" style={{ opacity: 0 }}>
            <h4 className="font-display text-sm uppercase tracking-wider text-white mb-6">
              {footerConfig.quickLinksTitle}
            </h4>
            <ul className="space-y-3">
              {footerConfig.quickLinks.map((link) => (
                <li key={link}>
                  <a
                    href="#"
                    className="text-sm text-[#A1A1AA] hover:text-[#FF4D00] transition-colors flex items-center gap-2 group"
                  >
                    <span>{link}</span>
                    <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="footer-column" style={{ opacity: 0 }}>
            <h4 className="font-display text-sm uppercase tracking-wider text-white mb-6">
              {footerConfig.contactTitle}
            </h4>
            <div className="flex items-start gap-3">
              <Mail className="w-4 h-4 text-[#FF4D00]/60 mt-0.5" />
              <div>
                <p className="text-sm text-[#A1A1AA]">{footerConfig.emailLabel}</p>
                <a
                  href={`mailto:${footerConfig.email}`}
                  className="text-sm text-white hover:text-[#FF4D00] transition-colors"
                >
                  {footerConfig.email}
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#A1A1AA]/50 font-mono-custom">
            {footerConfig.copyrightText}
          </p>
          <div className="flex gap-6">
            {footerConfig.bottomLinks.map((link) => (
              <a
                key={link}
                href="#"
                className="text-xs text-[#A1A1AA]/50 hover:text-white/80 transition-colors"
              >
                {link}
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF4D00]/20 to-transparent" />
    </footer>
  );
};

export default Footer;
