// =============================================================================
// CodeSlayers Site Configuration
// Edit ONLY this file to customize all content across the site.
// All animations, layouts, and styles are controlled by the components.
// =============================================================================

// -- Site-wide settings -------------------------------------------------------
export interface SiteConfig {
  title: string;
  description: string;
  language: string;
}

export const siteConfig: SiteConfig = {
  title: "CodeSlayers - Code. Compete. Conquer.",
  description: "The arena for serious builders. DSA, ML, and real-time coding battles.",
  language: "en",
};

// -- Hero Section -------------------------------------------------------------
export interface HeroNavItem {
  label: string;
  sectionId: string;
  icon: "code" | "book" | "sword" | "trophy";
}

export interface HeroConfig {
  backgroundImage: string;
  brandName: string;
  decodeText: string;
  decodeChars: string;
  subtitle: string;
  ctaPrimary: string;
  ctaPrimaryTarget: string;
  ctaSecondary: string;
  ctaSecondaryTarget: string;
  cornerLabel: string;
  cornerDetail: string;
  navItems: HeroNavItem[];
}

export const heroConfig: HeroConfig = {
  backgroundImage: "/hero-bg.jpg",
  brandName: "CodeSlayers",
  decodeText: "CODE. COMPETE. CONQUER.",
  decodeChars: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*",
  subtitle: "The arena for serious builders",
  ctaPrimary: "Start your streak",
  ctaPrimaryTarget: "stats",
  ctaSecondary: "Explore arena",
  ctaSecondaryTarget: "problems",
  cornerLabel: "PLATFORM",
  cornerDetail: "v2.0",
  navItems: [
    { label: "Problems", sectionId: "problems", icon: "code" },
    { label: "Courses", sectionId: "courses", icon: "book" },
    { label: "Arena", sectionId: "arena", icon: "sword" },
    { label: "Leaderboard", sectionId: "leaderboard", icon: "trophy" },
  ],
};

// -- Stats Dashboard Section (formerly AlbumCube) -----------------------------
export interface StatItem {
  label: string;
  value: string;
  icon: string;
}

export interface StatsConfig {
  title: string;
  subtitle: string;
  stats: StatItem[];
  note: string;
  ctaText: string;
  ctaTarget: string;
  cubeTextures: string[];
  scrollHint: string;
}

export const statsConfig: StatsConfig = {
  title: "SLAYER STATS",
  subtitle: "Your coding journey",
  stats: [
    { label: "Streak", value: "12 days", icon: "flame" },
    { label: "Rank", value: "Gold III", icon: "shield" },
    { label: "Level", value: "42", icon: "zap" },
    { label: "XP", value: "8,420 / 10,000", icon: "star" },
  ],
  note: "Solve daily to keep the streak alive. Miss a day = coin freeze.",
  ctaText: "View profile",
  ctaTarget: "profile",
  cubeTextures: [
    "/cube-face-1.jpg",
    "/cube-face-2.jpg",
    "/cube-face-3.jpg",
    "/cube-face-4.jpg",
    "/cube-face-5.jpg",
    "/cube-face-6.jpg",
  ],
  scrollHint: "Keep scrolling",
};

// -- Problem Gallery Section (formerly ParallaxGallery) -----------------------
export interface ProblemCard {
  id: number;
  title: string;
  difficulty: "Easy" | "Medium" | "Hard" | "Legendary";
  topic: string;
  image: string;
  solvedCount: string;
  acceptanceRate: string;
}

export interface ProblemGalleryConfig {
  sectionLabel: string;
  sectionTitle: string;
  galleryLabel: string;
  galleryTitle: string;
  marqueeTexts: string[];
  endCtaText: string;
  problems: ProblemCard[];
  filterTopics: string[];
}

export const problemGalleryConfig: ProblemGalleryConfig = {
  sectionLabel: "PROBLEM ARENA",
  sectionTitle: "Pick your battle.",
  galleryLabel: "BROWSE",
  galleryTitle: "Problems",
  marqueeTexts: [
    "TWO SUM",
    "MERGE K LISTS",
    "GRAPH VALID TREE",
    "LRU CACHE",
    "WORD LADDER II",
    "SLIDING WINDOW MAX",
  ],
  endCtaText: "Filter by topic",
  filterTopics: ["Arrays", "Trees", "DP", "Graphs", "Heap", "Design", "BFS", "DFS"],
  problems: [
    {
      id: 1,
      title: "Two Sum",
      difficulty: "Easy",
      topic: "Arrays",
      image: "/problem-1.jpg",
      solvedCount: "2.4M",
      acceptanceRate: "48%",
    },
    {
      id: 2,
      title: "Merge K Lists",
      difficulty: "Hard",
      topic: "Heap",
      image: "/problem-2.jpg",
      solvedCount: "890K",
      acceptanceRate: "32%",
    },
    {
      id: 3,
      title: "Graph Valid Tree",
      difficulty: "Medium",
      topic: "Graphs",
      image: "/problem-3.jpg",
      solvedCount: "1.2M",
      acceptanceRate: "45%",
    },
    {
      id: 4,
      title: "LRU Cache",
      difficulty: "Medium",
      topic: "Design",
      image: "/problem-4.jpg",
      solvedCount: "1.8M",
      acceptanceRate: "42%",
    },
    {
      id: 5,
      title: "Word Ladder II",
      difficulty: "Hard",
      topic: "BFS",
      image: "/problem-5.jpg",
      solvedCount: "420K",
      acceptanceRate: "28%",
    },
    {
      id: 6,
      title: "Sliding Window Max",
      difficulty: "Hard",
      topic: "Deque",
      image: "/problem-6.jpg",
      solvedCount: "680K",
      acceptanceRate: "35%",
    },
  ],
};

// -- Features Section (formerly TourSchedule) ---------------------------------
export interface FeatureItem {
  id: number;
  title: string;
  description: string;
  icon: string;
}

export interface TrackItem {
  id: number;
  name: string;
  modules: string[];
  color: string;
}

export interface FeaturesConfig {
  sectionLabel: string;
  sectionTitle: string;
  headline: string;
  body: string;
  features: FeatureItem[];
  tracks: TrackItem[];
  ctaText: string;
  ctaTarget: string;
  discImage: string;
}

export const featuresConfig: FeaturesConfig = {
  sectionLabel: "FEATURES",
  sectionTitle: "Learn. Build. Battle.",
  headline: "Courses that feel like quests.",
  body: "Code in a blazing-fast IDE. Duel in real-time arenas. Master DSA and ML with adaptive learning paths.",
  features: [
    {
      id: 1,
      title: "Blazing IDE",
      description: "Monaco-powered editor with custom themes, templates, and lightning-fast execution.",
      icon: "code",
    },
    {
      id: 2,
      title: "1v1 Battles",
      description: "Real-time coding duels with live leaderboard updates. Socket.io powered.",
      icon: "sword",
    },
    {
      id: 3,
      title: "Adaptive Paths",
      description: "AI-driven course reordering based on your weakest areas. Fill gaps faster.",
      icon: "brain",
    },
    {
      id: 4,
      title: "Spaced Repetition",
      description: "Smart reminders to revisit problems. 2x XP for revision streaks.",
      icon: "repeat",
    },
  ],
  tracks: [
    {
      id: 1,
      name: "DSA Track",
      modules: ["Arrays", "Graphs", "DP", "Advanced Algorithms"],
      color: "#FF4D00",
    },
    {
      id: 2,
      name: "ML Track",
      modules: ["Python Basics", "NumPy/Pandas", "Supervised Learning", "Neural Nets"],
      color: "#7C3AED",
    },
  ],
  ctaText: "Explore the arena",
  ctaTarget: "arena",
  discImage: "/contest-disc.png",
};

// -- Contests Section ---------------------------------------------------------
export interface ContestItem {
  id: number;
  type: string;
  title: string;
  date: string;
  difficulty: string;
  status: "live" | "upcoming" | "ended";
}

export interface ContestsConfig {
  sectionLabel: string;
  sectionTitle: string;
  contests: ContestItem[];
  ctaText: string;
  ctaTarget: string;
}

export const contestsConfig: ContestsConfig = {
  sectionLabel: "CONTESTS",
  sectionTitle: "Daily Challenge",
  contests: [
    {
      id: 1,
      type: "Daily",
      title: "Longest Palindrome Substring",
      date: "Today",
      difficulty: "Hard",
      status: "live",
    },
    {
      id: 2,
      type: "Weekly",
      title: "Binary Search Battle",
      date: "Mar 28, 20:00 IST",
      difficulty: "Medium",
      status: "upcoming",
    },
    {
      id: 3,
      type: "Biweekly",
      title: "Graph Gauntlet",
      date: "Apr 02, 20:00 IST",
      difficulty: "Hard",
      status: "upcoming",
    },
    {
      id: 4,
      type: "Special",
      title: "ML Inference Sprint",
      date: "Apr 10, 20:00 IST",
      difficulty: "Legendary",
      status: "upcoming",
    },
  ],
  ctaText: "View all contests",
  ctaTarget: "contests",
};

// -- CTA Section -------------------------------------------------------------
export interface CTAConfig {
  backgroundImage: string;
  headline: string;
  ctaText: string;
  ctaTarget: string;
  brandName: string;
  brandTagline: string;
  socialLinks: {
    icon: "github" | "discord" | "twitter" | "youtube";
    label: string;
    href: string;
  }[];
}

export const ctaConfig: CTAConfig = {
  backgroundImage: "/cta-portrait.jpg",
  headline: "Join the Arena.",
  ctaText: "Start free",
  ctaTarget: "signup",
  brandName: "CodeSlayers",
  brandTagline: "Built for builders. No fluff. All fire.",
  socialLinks: [
    { icon: "github", label: "GitHub", href: "https://github.com" },
    { icon: "discord", label: "Discord", href: "https://discord.com" },
    { icon: "twitter", label: "X", href: "https://twitter.com" },
    { icon: "youtube", label: "YouTube", href: "https://youtube.com" },
  ],
};

// -- Footer Section -----------------------------------------------------------
export interface FooterConfig {
  newsletterTitle: string;
  newsletterDescription: string;
  newsletterPlaceholder: string;
  newsletterButtonText: string;
  subscribeAlertMessage: string;
  quickLinksTitle: string;
  quickLinks: string[];
  contactTitle: string;
  emailLabel: string;
  email: string;
  copyrightText: string;
  bottomLinks: string[];
  brandName: string;
  brandDescription: string;
}

export const footerConfig: FooterConfig = {
  newsletterTitle: "Get the weekly arena digest.",
  newsletterDescription: "Weekly problems, contest alerts, and pro tips.",
  newsletterPlaceholder: "you@example.com",
  newsletterButtonText: "Subscribe",
  subscribeAlertMessage: "Thanks for subscribing! Check your inbox.",
  quickLinksTitle: "Quick Links",
  quickLinks: ["Problems", "Courses", "Arena", "Leaderboard", "Contests"],
  contactTitle: "Contact",
  emailLabel: "Email",
  email: "arena@codeslayers.dev",
  copyrightText: "© 2026 CodeSlayers. All rights reserved.",
  bottomLinks: ["Privacy Policy", "Terms of Service", "Code of Conduct"],
  brandName: "CodeSlayers",
  brandDescription: "The gamified coding platform for serious builders.",
};

// -- Gamification Config ------------------------------------------------------
export interface Rank {
  name: string;
  color: string;
  minXP: number;
  icon: string;
}

export interface Badge {
  id: number;
  name: string;
  description: string;
  icon: string;
  rarity: "common" | "rare" | "epic" | "legendary";
}

export interface GamificationConfig {
  ranks: Rank[];
  badges: Badge[];
}

export const gamificationConfig: GamificationConfig = {
  ranks: [
    { name: "Iron", color: "#6B7280", minXP: 0, icon: "shield" },
    { name: "Bronze", color: "#B45309", minXP: 1000, icon: "shield" },
    { name: "Silver", color: "#9CA3AF", minXP: 3000, icon: "shield" },
    { name: "Gold", color: "#EAB308", minXP: 7000, icon: "shield" },
    { name: "Platinum", color: "#14B8A6", minXP: 15000, icon: "shield" },
    { name: "Diamond", color: "#3B82F6", minXP: 30000, icon: "shield" },
    { name: "Slayer", color: "#FF4D00", minXP: 50000, icon: "crown" },
  ],
  badges: [
    { id: 1, name: "First Blood", description: "First solve of the day", icon: "droplet", rarity: "common" },
    { id: 2, name: "Speed Demon", description: "Solved in under 5 minutes", icon: "zap", rarity: "rare" },
    { id: 3, name: "7-Day Warrior", description: "7-day streak", icon: "flame", rarity: "rare" },
    { id: 4, name: "Tree Master", description: "Solved 50 tree problems", icon: "git-branch", rarity: "epic" },
    { id: 5, name: "ML Wizard", description: "Completed ML track", icon: "brain", rarity: "legendary" },
    { id: 6, name: "Battle King", description: "Won 10 arena duels", icon: "sword", rarity: "epic" },
  ],
};
