import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Github, MessageCircle, Twitter, Youtube } from 'lucide-react';
import { ctaConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

const ICON_MAP = {
  github: Github,
  discord: MessageCircle,
  twitter: Twitter,
  youtube: Youtube,
};

const CTASection = () => {
  // Null check: if config is empty, do not render
  if (!ctaConfig.headline && !ctaConfig.backgroundImage) {
    return null;
  }

  const sectionRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const scrollTriggerRef = useRef<ScrollTrigger | null>(null);

  useEffect(() => {
    if (!sectionRef.current) return;

    const ctx = gsap.context(() => {
      const st = ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top top',
        end: '+=120%',
        pin: true,
        scrub: 0.6,
        onUpdate: (self) => {
          const progress = self.progress;

          // ENTRANCE (0% - 30%)
          if (progress <= 0.3) {
            const entranceProgress = progress / 0.3;
            
            // Background entrance
            if (bgRef.current) {
              gsap.set(bgRef.current, {
                scale: 1.12 - 0.12 * entranceProgress,
                opacity: entranceProgress,
              });
            }
            
            // Content entrance
            if (contentRef.current) {
              const headline = contentRef.current.querySelector('.cta-headline');
              const cta = contentRef.current.querySelector('.cta-button');
              
              if (headline) {
                gsap.set(headline, {
                  y: 18 * (1 - Math.min(1, entranceProgress * 1.5)) + 'vh',
                  opacity: Math.min(1, entranceProgress * 1.5),
                });
              }
              if (cta) {
                gsap.set(cta, {
                  y: 10 * (1 - Math.min(1, (entranceProgress - 0.3) * 2)) + 'vh',
                  opacity: Math.min(1, (entranceProgress - 0.3) * 2),
                });
              }
            }
          }
          // SETTLE (30% - 70%)
          else if (progress <= 0.7) {
            if (bgRef.current) {
              gsap.set(bgRef.current, { scale: 1, opacity: 1 });
            }
            if (contentRef.current) {
              const headline = contentRef.current.querySelector('.cta-headline');
              const cta = contentRef.current.querySelector('.cta-button');
              
              if (headline) gsap.set(headline, { y: 0, opacity: 1 });
              if (cta) gsap.set(cta, { y: 0, opacity: 1 });
            }
          }
          // EXIT (70% - 100%)
          else {
            const exitProgress = (progress - 0.7) / 0.3;
            
            if (contentRef.current) {
              const headline = contentRef.current.querySelector('.cta-headline');
              const cta = contentRef.current.querySelector('.cta-button');
              
              if (headline) {
                gsap.set(headline, { opacity: 1 - exitProgress * 0.75 });
              }
              if (cta) {
                gsap.set(cta, { opacity: 1 - exitProgress * 0.75 });
              }
            }
            
            if (bgRef.current) {
              gsap.set(bgRef.current, { scale: 1 + 0.06 * exitProgress });
            }
          }
        },
      });

      scrollTriggerRef.current = st;

      return () => {
        st.kill();
      };
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="leaderboard"
      ref={sectionRef}
      className="relative w-full h-screen overflow-hidden z-40"
    >
      {/* Background image */}
      <div
        ref={bgRef}
        className="absolute inset-0 z-0"
        style={{ opacity: 0 }}
      >
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${ctaConfig.backgroundImage})` }}
        />
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0B0B0D]/35 via-[#0B0B0D]/50 to-[#0B0B0D]/75" />
      </div>

      {/* Content */}
      <div
        ref={contentRef}
        className="relative z-10 flex flex-col items-center justify-center h-full px-6"
      >
        {/* Headline */}
        <h2 className="cta-headline font-display text-6xl md:text-8xl lg:text-9xl text-white text-center mb-8 drop-shadow-2xl" style={{ opacity: 0 }}>
          {ctaConfig.headline}
        </h2>

        {/* CTA Button */}
        <button className="cta-button btn-primary text-lg px-10 py-4" style={{ opacity: 0 }}>
          {ctaConfig.ctaText}
        </button>
      </div>

      {/* Bottom info */}
      <div className="absolute bottom-12 left-12 z-20">
        <p className="font-display text-xl text-white mb-1">{ctaConfig.brandName}</p>
        <p className="font-mono-custom text-sm text-[#A1A1AA]">{ctaConfig.brandTagline}</p>
      </div>

      {/* Social links */}
      <div className="absolute bottom-12 right-12 z-20 flex items-center gap-4">
        {ctaConfig.socialLinks.map((link) => {
          const IconComponent = ICON_MAP[link.icon];
          return (
            <a
              key={link.label}
              href={link.href}
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-[#FF4D00]/20 hover:text-[#FF4D00] transition-colors"
            >
              <IconComponent className="w-5 h-5 text-white" />
            </a>
          );
        })}
      </div>
    </section>
  );
};

export default CTASection;
