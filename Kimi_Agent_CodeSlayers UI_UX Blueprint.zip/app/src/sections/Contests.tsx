import { useRef, useEffect, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Flame, Calendar, ArrowRight } from 'lucide-react';
import { contestsConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case 'Easy':
      return 'text-green-500';
    case 'Medium':
      return 'text-yellow-500';
    case 'Hard':
      return 'text-[#FF4D00]';
    case 'Legendary':
      return 'text-[#7C3AED]';
    default:
      return 'text-white';
  }
};

const getStatusBadge = (status: string) => {
  switch (status) {
    case 'live':
      return { text: 'LIVE', className: 'bg-red-500/20 text-red-400 animate-pulse' };
    case 'upcoming':
      return { text: 'UPCOMING', className: 'bg-[#FF4D00]/20 text-[#FF4D00]' };
    case 'ended':
      return { text: 'ENDED', className: 'bg-white/10 text-[#A1A1AA]' };
    default:
      return { text: 'UPCOMING', className: 'bg-white/10 text-[#A1A1AA]' };
  }
};

const Contests = () => {
  // Null check: if config is empty, do not render
  if (contestsConfig.contests.length === 0 && !contestsConfig.sectionTitle) {
    return null;
  }

  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const discRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    if (!sectionRef.current) return;

    const st = ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top 80%',
      onEnter: () => setIsVisible(true),
    });

    return () => {
      st.kill();
    };
  }, []);

  useEffect(() => {
    if (!isVisible || !contentRef.current) return;

    const ctx = gsap.context(() => {
      // Content animation
      gsap.fromTo(
        contentRef.current?.querySelectorAll('.contest-item') || [],
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6, stagger: 0.1, ease: 'power3.out' }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, [isVisible]);

  // Disc rotation on scroll
  useEffect(() => {
    if (!sectionRef.current || !discRef.current) return;

    const st = ScrollTrigger.create({
      trigger: sectionRef.current,
      start: 'top bottom',
      end: 'bottom top',
      scrub: 1,
      onUpdate: (self) => {
        if (discRef.current) {
          gsap.set(discRef.current, {
            rotation: self.progress * 180,
            y: Math.sin(self.progress * Math.PI) * 10,
          });
        }
      },
    });

    return () => {
      st.kill();
    };
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="arena"
      ref={sectionRef}
      className="relative w-full bg-[#0B0B0D] py-24 overflow-hidden"
    >
      {/* Rotating disc decoration */}
      <div
        ref={discRef}
        className="absolute top-20 right-20 w-48 h-48 md:w-64 md:h-64 z-10 opacity-30 pointer-events-none"
      >
        <div className="w-full h-full rounded-full border-2 border-[#FF4D00]/30 relative">
          <div className="absolute inset-4 rounded-full border border-[#7C3AED]/20" />
          <div className="absolute inset-8 rounded-full border border-[#FF4D00]/10" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-[#FF4D00]/50" />
          {/* Code pattern in center */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="font-mono-custom text-[8px] text-[#FF4D00]/20 text-center leading-tight">
              {'{ }'}
              <br />
              {'</>'}
            </div>
          </div>
        </div>
      </div>

      {/* Content container */}
      <div ref={contentRef} className="relative z-20 max-w-7xl mx-auto px-6 md:px-12">
        {/* Section header */}
        <div className="mb-16">
          <p className="font-mono-custom text-xs text-[#FF4D00]/60 uppercase tracking-wider mb-2">
            {contestsConfig.sectionLabel}
          </p>
          <h2 className="font-display text-5xl md:text-6xl text-white">
            {contestsConfig.sectionTitle}
          </h2>
        </div>

        {/* Contests list */}
        <div className="space-y-4 max-w-3xl">
          {contestsConfig.contests.map((contest) => {
            const status = getStatusBadge(contest.status);
            return (
              <div
                key={contest.id}
                className="contest-item card-dark p-6 group hover:-translate-y-0.5 transition-transform duration-300 cursor-pointer"
                style={{ opacity: 0 }}
              >
                <div className="flex flex-col md:flex-row md:items-center gap-4">
                  {/* Type badge */}
                  <div className="flex-shrink-0">
                    <span className="font-mono-custom text-xs text-[#A1A1AA] uppercase tracking-wider">
                      {contest.type}
                    </span>
                  </div>

                  {/* Title */}
                  <div className="flex-grow">
                    <h3 className="font-display text-lg text-white group-hover:text-[#FF4D00] transition-colors">
                      {contest.title}
                    </h3>
                  </div>

                  {/* Difficulty */}
                  <div className="flex items-center gap-2">
                    <Flame className={`w-4 h-4 ${getDifficultyColor(contest.difficulty)}`} />
                    <span className={`font-mono-custom text-sm ${getDifficultyColor(contest.difficulty)}`}>
                      {contest.difficulty}
                    </span>
                  </div>

                  {/* Date */}
                  <div className="flex items-center gap-2 text-[#A1A1AA]">
                    <Calendar className="w-4 h-4" />
                    <span className="font-mono-custom text-sm">{contest.date}</span>
                  </div>

                  {/* Status badge */}
                  <div className="flex-shrink-0">
                    <span className={`px-3 py-1 rounded-full text-xs font-mono-custom ${status.className}`}>
                      {status.text}
                    </span>
                  </div>

                  {/* Arrow */}
                  <div className="flex-shrink-0">
                    <ArrowRight className="w-5 h-5 text-white/20 group-hover:text-[#FF4D00] group-hover:translate-x-1 transition-all" />
                  </div>
                </div>

                {/* Hover indicator */}
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-0 bg-[#FF4D00] rounded-full group-hover:h-12 transition-all duration-300" />
              </div>
            );
          })}
        </div>

        {/* CTA */}
        <div className="mt-12">
          <button
            onClick={() => scrollToSection(contestsConfig.ctaTarget)}
            className="btn-secondary inline-flex items-center gap-2"
          >
            {contestsConfig.ctaText}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF4D00]/20 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#FF4D00]/20 to-transparent" />
    </section>
  );
};

export default Contests;
