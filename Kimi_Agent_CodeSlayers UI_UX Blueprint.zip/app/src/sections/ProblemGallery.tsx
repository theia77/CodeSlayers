import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Flame, Users, Percent, ArrowRight, Filter } from 'lucide-react';
import { problemGalleryConfig } from '../config';

gsap.registerPlugin(ScrollTrigger);

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case 'Easy':
      return 'text-green-500';
    case 'Medium':
      return 'text-yellow-500';
    case 'Hard':
      return 'text-[#FF4D00]';
    case 'Legendary':
      return 'text-[#7C3AED]';
    default:
      return 'text-white';
  }
};

const getDifficultyFlames = (difficulty: string) => {
  switch (difficulty) {
    case 'Easy':
      return 1;
    case 'Medium':
      return 2;
    case 'Hard':
      return 3;
    case 'Legendary':
      return 4;
    default:
      return 1;
  }
};

const ProblemGallery = () => {
  // Null check: if config is empty, do not render
  if (problemGalleryConfig.problems.length === 0 && !problemGalleryConfig.sectionTitle) {
    return null;
  }

  const sectionRef = useRef<HTMLDivElement>(null);
  const headerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const scrollTriggerRef = useRef<ScrollTrigger | null>(null);

  useEffect(() => {
    if (!sectionRef.current || !trackRef.current) return;

    const ctx = gsap.context(() => {
      const trackWidth = trackRef.current!.scrollWidth;
      const viewportWidth = window.innerWidth;

      const st = ScrollTrigger.create({
        trigger: sectionRef.current,
        start: 'top top',
        end: '+=150%',
        pin: true,
        scrub: 0.8,
        onUpdate: (self) => {
          const progress = self.progress;

          // ENTRANCE (0% - 30%)
          if (progress <= 0.3) {
            const entranceProgress = progress / 0.3;
            
            // Header entrance
            if (headerRef.current) {
              gsap.set(headerRef.current, {
                y: -10 * (1 - entranceProgress) + 'vh',
                opacity: entranceProgress,
              });
            }
            
            // Cards staggered entrance
            const cards = trackRef.current!.querySelectorAll('.problem-card');
            cards.forEach((card, index) => {
              const cardProgress = Math.max(0, Math.min(1, (entranceProgress - index * 0.1) * 2));
              gsap.set(card, {
                x: 60 * (1 - cardProgress) + 'vw',
                rotateZ: 6 * (1 - cardProgress),
                opacity: cardProgress,
              });
            });
          }
          // SETTLE + HORIZONTAL SCROLL (30% - 70%)
          else if (progress <= 0.7) {
            const scrollProgress = (progress - 0.3) / 0.4;
            
            if (headerRef.current) {
              gsap.set(headerRef.current, { y: 0, opacity: 1 });
            }
            
            if (trackRef.current) {
              const x = -scrollProgress * (trackWidth - viewportWidth + 200);
              gsap.set(trackRef.current, { x });
            }
          }
          // EXIT (70% - 100%)
          else {
            const exitProgress = (progress - 0.7) / 0.3;
            
            if (headerRef.current) {
              gsap.set(headerRef.current, {
                y: -12 * exitProgress + 'vh',
                opacity: 1 - exitProgress * 0.75,
              });
            }
            
            if (trackRef.current) {
              const currentX = gsap.getProperty(trackRef.current, 'x') as number;
              gsap.set(trackRef.current, {
                x: currentX - 40 * exitProgress,
                opacity: 1 - exitProgress * 0.7,
              });
            }
          }
        },
      });

      scrollTriggerRef.current = st;

      return () => {
        st.kill();
      };
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="problems"
      ref={sectionRef}
      className="relative w-full h-screen bg-[#0B0B0D] overflow-hidden z-30"
    >
      {/* Header */}
      <div
        ref={headerRef}
        className="absolute top-[10vh] left-[6vw] z-20"
        style={{ opacity: 0 }}
      >
        <p className="font-mono-custom text-xs text-[#FF4D00]/60 uppercase tracking-wider mb-2">
          {problemGalleryConfig.sectionLabel}
        </p>
        <h2 className="font-display text-4xl md:text-5xl text-white">
          {problemGalleryConfig.sectionTitle}
        </h2>
      </div>

      {/* Filter button */}
      <div className="absolute top-[10vh] right-[6vw] z-20">
        <button className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 hover:border-[#FF4D00]/30 transition-colors">
          <Filter className="w-4 h-4 text-[#A1A1AA]" />
          <span className="font-mono-custom text-sm text-[#A1A1AA]">{problemGalleryConfig.endCtaText}</span>
        </button>
      </div>

      {/* Horizontal scrolling track */}
      <div
        ref={trackRef}
        className="absolute top-[26vh] left-0 flex items-center gap-[3vw] h-[56vh] px-[10vw] will-change-transform"
      >
        {problemGalleryConfig.problems.map((problem) => (
          <div
            key={problem.id}
            className="problem-card relative flex-shrink-0 w-[28vw] h-[44vh] card-dark overflow-hidden group cursor-pointer hover:-translate-y-1.5 transition-transform duration-300"
            style={{ opacity: 0 }}
          >
            {/* Image */}
            <div className="relative h-[55%] overflow-hidden">
              <img
                src={problem.image}
                alt={problem.title}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#141419] to-transparent" />
              
              {/* Difficulty badge */}
              <div className="absolute top-4 left-4 flex items-center gap-1">
                {[...Array(getDifficultyFlames(problem.difficulty))].map((_, i) => (
                  <Flame key={i} className={`w-4 h-4 ${getDifficultyColor(problem.difficulty)}`} />
                ))}
              </div>
            </div>

            {/* Content */}
            <div className="p-6">
              <h3 className="font-display text-xl text-white mb-2 group-hover:text-[#FF4D00] transition-colors">
                {problem.title}
              </h3>
              
              <div className="flex items-center gap-2 mb-4">
                <span className={`font-mono-custom text-xs ${getDifficultyColor(problem.difficulty)}`}>
                  {problem.difficulty}
                </span>
                <span className="text-white/20">/</span>
                <span className="font-mono-custom text-xs text-[#A1A1AA]">{problem.topic}</span>
              </div>

              {/* Stats */}
              <div className="flex items-center justify-between pt-4 border-t border-white/5">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-[#A1A1AA]" />
                  <span className="font-mono-custom text-xs text-[#A1A1AA]">{problem.solvedCount}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Percent className="w-4 h-4 text-[#A1A1AA]" />
                  <span className="font-mono-custom text-xs text-[#A1A1AA]">{problem.acceptanceRate}</span>
                </div>
              </div>
            </div>

            {/* Hover overlay */}
            <div className="absolute inset-0 bg-[#FF4D00]/0 group-hover:bg-[#FF4D00]/5 transition-colors duration-300 pointer-events-none" />
          </div>
        ))}

        {/* End CTA card */}
        <div className="flex-shrink-0 w-[28vw] h-[44vh] flex flex-col items-center justify-center card-dark">
          <button className="group flex flex-col items-center gap-4 text-white hover:text-[#FF4D00] transition-colors">
            <div className="w-16 h-16 rounded-full border border-white/20 group-hover:border-[#FF4D00] flex items-center justify-center transition-colors">
              <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
            </div>
            <span className="font-display text-lg uppercase tracking-wider">
              View all
            </span>
          </button>
        </div>
      </div>

      {/* Marquee at bottom */}
      <div className="absolute bottom-0 left-0 right-0 py-4 bg-[#141419]/50 border-t border-white/5 overflow-hidden">
        <div className="animate-marquee flex whitespace-nowrap">
          {[...Array(4)].map((_, i) => (
            <span key={i} className="flex items-center gap-8 mx-8">
              {problemGalleryConfig.marqueeTexts.map((text, j) => (
                <span key={j} className="font-mono-custom text-sm text-white/20 uppercase tracking-wider">
                  {text}
                </span>
              ))}
            </span>
          ))}
        </div>
      </div>

      {/* Scroll hint */}
      <div className="absolute bottom-20 right-8 z-20">
        <p className="font-mono-custom text-xs text-white/40">Scroll to browse</p>
      </div>
    </section>
  );
};

export default ProblemGallery;
